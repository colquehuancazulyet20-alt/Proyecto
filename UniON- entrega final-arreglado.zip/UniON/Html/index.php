<?php
session_start();
require_once("../php/connection.php");
$conn = connection();



?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>1er Grado</title>
  <link rel="stylesheet" href="index.css" />
  <link rel="icon" href="img/index/logo.png" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
</head>
<body>

  <!-- NAVBAR -->
  <nav class="navbar">
    <div class="navbar-container">
      <div class="logo">
        <img src="img/index/logo.png" alt="Logo" />
      </div>
      <div class="menu">
        <button class="hover" onclick="location.href='#Cursos'">Cursos</button>
        <button class="hover" onclick="location.href='#Foro'">Foro</button>
        <button class="hover" onclick="location.href='#Comunicación'">Comunicación</button>
      </div>
      <div class="perfil">
        <a href="../php/index.html">
          <img src="img/index/perfil-logo.png" alt="Login" />
        </a>
      </div>
    </div>
  </nav>

  <!-- CARRUSEL -->
  <div class="carousel-container">
    <div class="carousel-slide" id="carousel-slide">
      <img src="img/Carrusel/Escuela.jpg" alt="Imagen 1" />
      <img src="img/Carrusel/Escuela2.jpg" alt="Imagen 2" />
      <img src="img/Carrusel/Escuela3.jpg" alt="Imagen 3" />
    </div>
  </div>

  <div class="institucional">
    Escuela Primaria N°23 D.E.20
  </div>

  <!-- CURSOS -->
  <div class="centro">
    <div class="bloque1">
      <section id="Cursos">
        <h2>Cursos</h2>
        <div class="grados">
          <a href="../php/index.html" class="grado">1er Grado</a>
          <a href="../php/Cursos/segundo.php" class="grado">2do Grado</a>
          <a href="../php/Cursos/tercero.php" class="grado">3er Grado</a>
          <a href="../php/Cursos/cuarto.php" class="grado">4to Grado</a>
          <a href="../php/Cursos/quinto.php" class="grado">5to Grado</a>
          <a href="../php/Cursos/sexto.php" class="grado">6to Grado</a>
          <a href="../php/Cursos/septimo.php" class="grado">7mo Grado</a>

          <?php
          $usuarioID = $_SESSION['UsuarioID'] ?? null;
          if ($usuarioID) {
            $sql = "SELECT c.ID, c.nombre FROM cursos c
                    JOIN login u ON u.Curso = c.ID
                    WHERE u.ID = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $usuarioID);
            $stmt->execute();
            $result = $stmt->get_result();

            while ($row = $result->fetch_assoc()) {
              echo "<a href='../php/Cursos/{$row['ID']}.php' class='grado'>{$row['nombre']}</a>";
            }
          } else {
            echo "<p>Iniciá sesión para ver tus cursos.</p>";
          }
          ?>
        </div>
      </section>
    </div>

    <!-- FORO -->
    <div class="Comunicados">
      <div class="bloque2">
        <section id="Foro">
          <form action="../php/anuncios/crear_anuncio.php" method="POST">
            <div class="tarjeta-anuncio">
              <div class="texto">
                <textarea name="contenido" class="input-anuncio" placeholder="Anuncia algo a la clase..." required></textarea>
                <input type="hidden" name="usuarioID" value="<?php echo $_SESSION['UsuarioID'] ?? ''; ?>" />
                <input type="hidden" name="cursoID" value="0" />
              </div>
              <button type="submit" class="btn-publicar">Publicar</button>
            </div>
          </form>

          <div class="contenedor-anuncios">
            <?php
            $cursoID = 0;
            include("../php/mostrar_contenido.php");
            ?>
          </div>
        </section>
      </div>
    </div>
  </div>

  <!-- COMUNICACIÓN -->
  <section id="Comunicación">
    <div class="contenido">
      <h2><i class="fas fa-map-marker-alt"></i> Dirección</h2>
      <iframe src="https://www.google.com/maps/embed?pb=..." width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    </div>
    <footer>
      <div class="contactos">
        <p class="titulo"> Contactos</p>
        <p><i class="fa-solid fa-phone"></i> 11999999</p>
        <p><i class="fa-solid fa-envelope"></i> consultas.ed23@gmail.com</p>
      </div>
      <div class="contactos">
        <p class="titulo">Síguenos</p>
        <p><i class="fa-brands fa-instagram"></i>Instagram </p>
      </div>
      <div class="contactos">
        <img src="Img/footer/Logo-footer.png" alt="Logo" class="logo" />
      </div>
      <p>© 2025 - Todos los derechos reservados</p>
    </footer>
  </section>

  <script>
    const slide = document.getElementById('carousel-slide');
    let index = 0;
    setInterval(() => {
      index = (index + 1) % 3;
      slide.style.transform = `translateX(-${index * 100}%)`;
    }, 3000);
  </script>
</body>
</html>
