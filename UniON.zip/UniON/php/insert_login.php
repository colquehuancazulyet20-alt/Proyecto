<?php
include("connection.php");
$con = connection();

$Nombre = $_POST['Nombre'];
$Apellido = $_POST['Apellido'];
$Usuario = $_POST['Usuario'];
$Contraseña = $_POST['Contraseña'];
$Rol = $_POST['Rol'];
$Curso = $_POST['Curso'];

$sql = "INSERT INTO login (Nombre, Apellido, Usuario, Contraseña, Rol, Curso) VALUES ('$Nombre', '$Apellido', '$Usuario', '$Contraseña', '$Rol', '$Curso')";

$query = mysqli_query($con, $sql);

if($query){
    Header("Location: index.php");
}else{

}
if (!$query) {
    echo "Error: " . mysqli_error($con);
}

?>