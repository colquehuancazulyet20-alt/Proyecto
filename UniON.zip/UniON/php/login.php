<?php
session_start();
include 'connection.php'; // 👈 Esto importa tu función

$conn = connection(); // 👈 Esto la ejecuta y te da la conexión

$Usuario = $_POST['Usuario'];
$Contraseña = $_POST['Contraseña'];

$sql = "SELECT * FROM login WHERE Usuario = ? AND Contraseña = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $Usuario, $Contraseña);
$stmt->execute();
$result = $stmt->get_result();

if (!isset($_POST['Usuario']) || !isset($_POST['Contraseña'])) {
    echo "⚠️ Faltan datos del formulario.";
    exit();
}

if ($row = $result->fetch_assoc()) {
    $_SESSION['Usuario'] = $row['Usuario'];
    $_SESSION['Rol'] = strtolower(trim($row['Rol']));
    $_SESSION['Curso'] = $row['Curso'];

if($_SESSION['Rol'] === 'admin') {
    header("Location: index.php");
}else{
header("Location: Cursos/" . $_SESSION['Curso'] . ".html");
}
    exit();
} else {
    echo "❌ Usuario o contraseña incorrectos.";
}

$conn->close();
?>