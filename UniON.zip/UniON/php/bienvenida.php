<?php
session_start();

// Verificamos que el usuario esté logueado
if (!isset($_SESSION['Usuario'])) {
    header("Location: index.html");
    exit();
}

$usuario = $_SESSION['Usuario'];
$rol = strtolower(trim($_SESSION['Rol']));
$curso = $_SESSION['Curso'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Bienvenida</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 30px;
            background-color: #f9f9f9;
        }
        h1 {
            color: #333;
        }
        .info {
            margin-top: 20px;
        }
        a {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            background-color: #0077cc;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        a:hover {
            background-color: #005fa3;
        }
    </style>
</head>
<body>
    <h1>👋 Bienvenida, <?php echo $usuario; ?>!</h1>

    <div class="info">
        <p><strong>Rol:</strong> <?php echo ucfirst($rol); ?></p>
        <p><strong>Curso asignado:</strong> <?php echo $curso; ?></p>
    </div>

    <?php if ($rol === 'admin'): ?>
        <a href="index.php">Ir al panel de administración</a>
    <?php elseif ($rol === 'tutor'): ?>
        <a href="Cursos/<?php echo $curso; ?>.html">Ir al curso</a>
    <?php else: ?>
        <p>⚠️ Rol no reconocido.</p>
    <?php endif; ?>

    <br><br>
    <a href="logout.php">Cerrar sesión</a>
</body>
</html>
